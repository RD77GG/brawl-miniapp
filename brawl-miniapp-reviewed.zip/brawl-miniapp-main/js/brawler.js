const params = new URLSearchParams(window.location.search);
const name = params.get("name");

const currencyIcons = {
    gems: "assets/currencies/gems.WEBP",
    blings: "assets/currencies/blings.WEBP",
    coins: "assets/currencies/coins.WEBP"
};

function renderPriceOrSource(skin) {
    const source = skin.source || { type: "shop" };

    if (source.type === "brawl_pass" || source.type === "pro_pass") {
        const fallbackName = source.type === "brawl_pass" ? "Brawl Pass" : "Pro Pass";
        const fallbackIcon = source.type === "brawl_pass"
            ? "assets/collections/brawl_pass.WEBP"
            : "assets/collections/pro_pass.WEBP";

        return `
            <div class="skin-source">
                <img src="${source.icon || fallbackIcon}" alt="" class="skin-source-icon">
                <span>${source.name || fallbackName}</span>
            </div>
        `;
    }

    if (source.type === "free") {
        return `<div class="skin-source skin-source-free">Бесплатно</div>`;
    }

    const price = skin.price || {};
    const priceItems = [];

    if (price.gems !== undefined) {
        priceItems.push(`
            <span class="skin-price-item">
                <img src="${currencyIcons.gems}" alt="Гемы">
                <span>${price.gems}</span>
            </span>
        `);
    }

    if (price.blings !== undefined) {
        priceItems.push(`
            <span class="skin-price-item">
                <img src="${currencyIcons.blings}" alt="Блинги">
                <span>${price.blings}</span>
            </span>
        `);
    }

    if (price.coins !== undefined) {
        priceItems.push(`
            <span class="skin-price-item">
                <img src="${currencyIcons.coins}" alt="Монеты">
                <span>${price.coins}</span>
            </span>
        `);
    }

    return priceItems.length
        ? `<div class="skin-price">${priceItems.join("")}</div>`
        : `<div class="skin-source skin-source-unavailable">Недоступен</div>`;
}

function renderCollection(skin) {
    if (!skin.collection || !skin.collection.name) {
        return "";
    }

    const icon = skin.collection.icon
        ? `<img src="${skin.collection.icon}" alt="" class="skin-collection-icon" onerror="this.style.display='none'">`
        : "";

    return `
        <div class="skin-collection">
            ${icon}
            <span>${skin.collection.name}</span>
        </div>
    `;
}

fetch("data/brawlers.json")
    .then(response => {
        if (!response.ok) {
            throw new Error(`Ошибка загрузки JSON: ${response.status}`);
        }
        return response.json();
    })
    .then(brawlers => {
        const brawler = brawlers.find(item => item.name === name);
        const root = document.getElementById("brawler");

        if (!brawler) {
            root.innerHTML = "<h2 class=\"page-message\">Боец не найден</h2>";
            return;
        }

        root.innerHTML = `
            <div class="brawler-main">
                <img
                    src="${brawler.image}"
                    class="main-image"
                    alt="${brawler.displayName}">

                <h1 class="brawler-name">${brawler.displayName}</h1>

                <div class="info-card">
                    <p>
                        <strong>⭐ Редкость:</strong>
                        <span class="rarity ${brawler.rarityClass}">${brawler.rarity}</span>
                    </p>
                    <p>
                        <strong>⚔️ Класс:</strong>
                        <span class="class-tag ${brawler.classClass}">${brawler.class}</span>
                    </p>
                </div>

                <div class="tabs" role="tablist" aria-label="Разделы бойца">
                    <button class="tab active" id="skinsTab" type="button" role="tab" aria-selected="true">
                        🎨 Скины
                    </button>
                    <button class="tab" id="infoTab" type="button" role="tab" aria-selected="false">
                        📖 Информация
                    </button>
                </div>

                <section id="skinsContent" role="tabpanel">
                    <h2>Скины (${brawler.skins.length})</h2>

                    <div class="skins">
                        ${brawler.skins.map((skin, index) => `
                            <article class="skin-card" data-skin-index="${index}">
                                <div class="skin-image-wrap">
                                    <img
                                        src="${skin.image}"
                                        alt="${skin.displayName}"
                                        class="skin-image">
                                </div>

                                <div class="skin-card-body">
                                    <h3>${skin.displayName}</h3>

                                    ${renderCollection(skin)}

                                    <div class="skin-rarity ${skin.rarityClass || ""}">
                                        ${skin.rarity || "Редкость не указана"}
                                    </div>

                                    ${renderPriceOrSource(skin)}

                                    <div class="skin-year">${skin.releaseYear || "—"}</div>
                                </div>
                            </article>
                        `).join("")}
                    </div>
                </section>

                <section id="infoContent" role="tabpanel" hidden>
                    <div class="titles-card">
                        <h2>🏆 Титулы</h2>
                        ${(brawler.titles || []).map(title => `
                            <p>
                                <strong>${title.prime} Прайм:</strong>
                                ${title.name}
                            </p>
                        `).join("")}
                    </div>

                    <div class="info-card">
                        <h2>⭐ Способности</h2>
                        <p>⭐ Звёздные силы — скоро</p>
                        <p>🔧 Гаджеты — скоро</p>
                        <p>⚡ Гиперзаряд — скоро</p>
                    </div>
                </section>
            </div>
        `;

        const skinsTab = document.getElementById("skinsTab");
        const infoTab = document.getElementById("infoTab");
        const skinsContent = document.getElementById("skinsContent");
        const infoContent = document.getElementById("infoContent");

        function showTab(tabName) {
            const showSkins = tabName === "skins";

            skinsContent.hidden = !showSkins;
            infoContent.hidden = showSkins;

            skinsTab.classList.toggle("active", showSkins);
            infoTab.classList.toggle("active", !showSkins);

            skinsTab.setAttribute("aria-selected", String(showSkins));
            infoTab.setAttribute("aria-selected", String(!showSkins));
        }

        skinsTab.addEventListener("click", () => showTab("skins"));
        infoTab.addEventListener("click", () => showTab("info"));
    })
    .catch(error => {
        console.error(error);
        document.getElementById("brawler").innerHTML =
            "<h2 class=\"page-message\">Ошибка загрузки данных</h2>";
    });
